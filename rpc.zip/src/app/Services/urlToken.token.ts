import { InjectionToken } from "@angular/core";
export const USERS_URL = new InjectionToken<string>('USERS_URL');